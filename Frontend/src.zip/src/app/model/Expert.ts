export class Expert {
    constructor(public name: string, public password: string, public specializations: string[]) { }
}
