export class User {
    constructor(public name: string, public password: string, public position :string,public company: string) { }
}
