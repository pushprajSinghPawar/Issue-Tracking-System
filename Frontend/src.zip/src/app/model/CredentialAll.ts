export class CredentialsAll {
    constructor(public name: string, public password: string) { }
}
