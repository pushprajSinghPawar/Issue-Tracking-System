import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CredentialsAll } from '../model/CredentialAll';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  loginForm = new FormGroup({
    username: new FormControl('', [
      Validators.required 
    ]),
    password: new FormControl('', [
      Validators.required
    ])
  });

  credential:CredentialsAll=new CredentialsAll("","");
  constructor(private router: Router) {}


  login() {
    if (this.loginForm.invalid) {
      if(this.loginForm.value.username===null || this.loginForm.value.username===""){
        alert('Give username');
        return;
      }
      if(this.loginForm.value.password===null || this.loginForm.value.password===""){
        alert('Give password');
        return;
      }
    };
    if(this.loginForm.value.password!==null || this.loginForm.value.username!==null){
      var un = this.loginForm.value.password ?? "";
      var pw = this.loginForm.value.username ?? "";
      this.credential.name=un;
      this.credential.password=pw;
      console.log(this.credential);
    }
    this.loginForm.reset();
    this.router.navigate(['/userdashboard']);

  }
}
