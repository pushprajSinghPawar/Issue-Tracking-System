import { Component } from '@angular/core';

@Component({
  selector: 'app-expertdashboard',
  templateUrl: './expertdashboard.component.html',
  styleUrl: './expertdashboard.component.css'
})
export class ExpertdashboardComponent {

}
